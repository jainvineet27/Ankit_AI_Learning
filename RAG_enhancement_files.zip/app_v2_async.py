"""
RAG Q&A Chatbot - Version 2: Async Streamlit App
Handles multiple concurrent users without blocking.
Each user gets an isolated session; heavy I/O runs in a thread-pool so
Streamlit's event loop is never blocked.
"""

import asyncio
import os
from concurrent.futures import ThreadPoolExecutor

import streamlit as st
from chromadb import PersistentClient
from dotenv import load_dotenv
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from openai import AsyncOpenAI          # ← async client

load_dotenv()

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="RAG Document Assistant",
    page_icon="📚",
    layout="wide",
)

# ── Shared thread-pool for CPU-bound / blocking I/O ───────────────────────────
# This lets multiple users run blocking ChromaDB / file ops concurrently
_EXECUTOR = ThreadPoolExecutor(max_workers=8)

# ── Cached shared resources (one instance for ALL sessions) ───────────────────
@st.cache_resource
def get_shared_resources():
    """
    ChromaDB and OpenAI clients are created ONCE and reused across sessions.
    AsyncOpenAI is thread-safe; PersistentClient is process-safe.
    """
    chroma_client = PersistentClient(path="./chromadb")
    collection = chroma_client.get_or_create_collection(
        name="dump", metadata={"hnsw:space": "cosine"}
    )
    openai_client = AsyncOpenAI()           # async version
    return collection, openai_client

collection, async_client = get_shared_resources()

# ── Async helper: run blocking code in executor ────────────────────────────────
async def run_in_executor(fn, *args):
    """Offload a blocking function to the thread-pool."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(_EXECUTOR, fn, *args)

# ── Core async RAG functions ───────────────────────────────────────────────────
async def async_create_embeddings(texts: list[str], dimensions: int = 300) -> list:
    """
    Calls OpenAI embeddings endpoint asynchronously.
    Multiple sessions can await this concurrently — they don't block each other.
    """
    response = await async_client.embeddings.create(
        model="text-embedding-3-small",
        input=texts,
        dimensions=dimensions,
    )
    return [item.embedding for item in response.data]


async def async_similarity_search(query_embedding: list) -> dict:
    """
    ChromaDB query is synchronous/blocking, so we offload it to the executor.
    """
    def _query():
        return collection.query(query_embeddings=query_embedding, n_results=3)

    return await run_in_executor(_query)


async def async_ask_question(user_query: str, chat_history: list) -> tuple[str, list]:
    """
    Full async RAG pipeline:
      1. Embed query (async, non-blocking)
      2. Search ChromaDB (in executor, non-blocking)
      3. Call GPT (async, non-blocking with streaming)
    """
    # Step 1 — embed
    user_embedding = await async_create_embeddings([user_query])

    # Step 2 — retrieve
    search_results = await async_similarity_search(user_embedding)
    retrieved_context = "\n".join(search_results["documents"][0])
    sources = [m.get("file_name", "unknown") for m in search_results["metadatas"][0]]

    # Step 3 — build prompt with history
    history_text = ""
    for msg in chat_history[-6:]:
        role = "User" if msg["role"] == "user" else "Assistant"
        history_text += f"{role}: {msg['content']}\n"

    prompt = f"""You are a helpful HR document assistant.
Use the retrieved context to answer the user's question accurately.

Conversation so far:
{history_text}

Retrieved Context from documents:
{retrieved_context}

User Question: {user_query}

Rules:
- Answer only from the provided context.
- Be concise and use bullet points where helpful.
- Do not hallucinate.
"""
    # Step 4 — streaming LLM response (non-blocking)
    full_answer = ""
    placeholder = st.empty()

    async with async_client.chat.completions.stream(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
    ) as stream:
        async for chunk in stream:
            delta = chunk.choices[0].delta.content or ""
            full_answer += delta
            placeholder.markdown(full_answer + "▌")   # live typing effect

    placeholder.markdown(full_answer)
    return full_answer, sources


# ── Async ingest pipeline ──────────────────────────────────────────────────────
async def async_ingest_documents():
    """Reads PDFs, chunks, embeds and stores — all without blocking the event loop."""
    folder_name = "source"
    if not os.path.isdir(folder_name):
        return 0, 0

    # File I/O in executor
    def _load_files():
        docs = []
        for file in os.listdir(folder_name):
            if file.endswith(".pdf"):
                path = os.path.abspath(os.path.join(folder_name, file))
                loader = PyMuPDFLoader(path)
                docs.append(loader.load())
        return docs

    documents_list = await run_in_executor(_load_files)
    if not documents_list:
        return 0, 0

    # Chunking in executor (CPU-bound)
    def _chunk(docs):
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=500, chunk_overlap=100, separators=["\n\n", "\n", " ", "."]
        )
        chunks_data, metadatas, ids = [], [], []
        for documents in docs:
            for i, chunk_obj in enumerate(splitter.split_documents(documents)):
                file_name = os.path.basename(chunk_obj.metadata.get("file_path", ""))
                chunks_data.append(chunk_obj.page_content)
                metadatas.append({"file_name": file_name})
                ids.append(f"chunk_{file_name}_{i}")
        return chunks_data, metadatas, ids

    chunks, metadatas, ids = await run_in_executor(_chunk, documents_list)

    # Embeddings — async, non-blocking
    embeddings = await async_create_embeddings(chunks)

    # Write to ChromaDB in executor
    def _store():
        collection.add(ids=ids, embeddings=embeddings, documents=chunks, metadatas=metadatas)

    await run_in_executor(_store)
    return len(chunks), len(documents_list)


# ── Utility to run coroutines from Streamlit's sync context ───────────────────
def run_async(coro):
    """
    Streamlit runs in a sync context. This helper lets us call async functions
    safely without creating a new event loop on every call.
    """
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(coro)


# ── Sidebar ────────────────────────────────────────────────────────────────────
with st.sidebar:
    st.title("📚 RAG Assistant")
    st.caption("Async · Multi-user · Streaming")
    st.divider()

    st.header("⚙️ Document Ingestion")
    if st.button("📥 Ingest Documents", use_container_width=True):
        with st.spinner("Indexing documents (async)…"):
            n_chunks, n_files = run_async(async_ingest_documents())
        if n_files:
            st.success(f"✅ {n_chunks} chunks from {n_files} file(s) indexed.")
        else:
            st.error("⚠️ No PDFs found in `source/` folder.")

    st.divider()

    # Session info
    session_id = st.session_state.get("session_id", id(st.session_state))
    st.session_state["session_id"] = session_id
    st.caption(f"🔑 Session: `{session_id}`")
    st.caption("Each browser tab = isolated session")

    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

    st.divider()
    st.markdown("### How to use")
    st.markdown("1. Add PDFs to `source/`\n2. Click **Ingest Documents**\n3. Ask away!")


# ── Main chat area ─────────────────────────────────────────────────────────────
st.title("📚 RAG Document Assistant")
st.caption("Async · Multi-user · Streaming responses")
st.divider()

if "messages" not in st.session_state:
    st.session_state.messages = []

# Render history
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("sources"):
            st.caption(f"📄 Sources: {', '.join(set(msg['sources']))}")

# Chat input
if prompt := st.chat_input("Ask a question about your documents…"):
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    with st.chat_message("assistant"):
        # run_async drives the full streaming pipeline
        answer, sources = run_async(
            async_ask_question(prompt, st.session_state.messages)
        )
        st.caption(f"📄 Sources: {', '.join(set(sources))}")

    st.session_state.messages.append({
        "role": "assistant",
        "content": answer,
        "sources": sources,
    })
