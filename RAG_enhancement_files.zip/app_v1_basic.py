"""
RAG Q&A Chatbot - Version 1: Basic Streamlit App
Uses your existing ChromaDB + OpenAI RAG pipeline with chat history.
"""

import os
import streamlit as st
from chromadb import PersistentClient
from dotenv import load_dotenv
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from openai import OpenAI

load_dotenv()

# ── Page config ────────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="RAG Document Assistant",
    page_icon="📚",
    layout="wide",
)

# ── Title & description ────────────────────────────────────────────────────────
st.title("📚 RAG Document Assistant")
st.caption("Ask questions about your documents — powered by ChromaDB + OpenAI")
st.divider()

# ── Initialize clients (cached so they are created once per session) ───────────
@st.cache_resource
def get_clients():
    chroma_client = PersistentClient(path="./chromadb")
    collection = chroma_client.get_or_create_collection(
        name="dump", metadata={"hnsw:space": "cosine"}
    )
    openai_client = OpenAI()
    return collection, openai_client

collection, client = get_clients()

# ── Helper functions (same as your original code) ─────────────────────────────
def read_document():
    documents_list = []
    folder_name = "source"
    if not os.path.isdir(folder_name):
        st.error(f"⚠️ Folder '{folder_name}' not found. Please create it and add PDFs.")
        return []
    for file in os.listdir(folder_name):
        if file.endswith(".pdf"):
            file_path = os.path.abspath(os.path.join(folder_name, file))
            loader = PyMuPDFLoader(file_path)
            documents_list.append(loader.load())
    return documents_list

def create_chunks(documents_list):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=500, chunk_overlap=100, separators=["\n\n", "\n", " ", "."]
    )
    chunks_data, metadatas, ids = [], [], []
    for documents in documents_list:
        chunks = splitter.split_documents(documents)
        for i, chunk_obj in enumerate(chunks):
            chunk_text = chunk_obj.page_content
            raw_path = chunk_obj.metadata.get("file_path", "")
            file_name = os.path.basename(raw_path)
            chunks_data.append(chunk_text)
            metadatas.append({"file_name": file_name})
            ids.append(f"chunk_{file_name}_{i}")
    return chunks_data, metadatas, ids

def create_batch_embeddings(chunks, dimensions=300):
    response = client.embeddings.create(
        model="text-embedding-3-small", input=chunks, dimensions=dimensions
    )
    return [item.embedding for item in response.data]

def similarity_search(query_embedding):
    return collection.query(query_embeddings=query_embedding, n_results=3)

def ask_question(user_query: str, chat_history: list) -> tuple[str, list]:
    """Embed the query, retrieve context, call GPT, return answer + sources."""
    user_embedding = create_batch_embeddings([user_query])
    search_results = similarity_search(user_embedding)
    retrieved_context = "\n".join(search_results["documents"][0])
    sources = [
        m.get("file_name", "unknown")
        for m in search_results["metadatas"][0]
    ]

    # Build history string for context
    history_text = ""
    for msg in chat_history[-6:]:           # last 3 turns
        role = "User" if msg["role"] == "user" else "Assistant"
        history_text += f"{role}: {msg['content']}\n"

    prompt = f"""You are a helpful HR document assistant.
Use the retrieved context to answer the user's question accurately.

Conversation so far:
{history_text}

Retrieved Context from documents:
{retrieved_context}

User Question: {user_query}

Rules:
- Answer only from the provided context.
- Be concise and use bullet points where helpful.
- Do not hallucinate.
"""
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
    )
    answer = response.choices[0].message.content
    return answer, sources

# ── Sidebar: ingest documents ─────────────────────────────────────────────────
with st.sidebar:
    st.header("⚙️ Document Ingestion")
    if st.button("📥 Ingest Documents", use_container_width=True):
        with st.spinner("Reading and indexing documents…"):
            docs = read_document()
            if docs:
                chunks, metadatas, ids = create_chunks(docs)
                embeddings = create_batch_embeddings(chunks)
                collection.add(
                    ids=ids,
                    embeddings=embeddings,
                    documents=chunks,
                    metadatas=metadatas,
                )
                st.success(f"✅ Indexed {len(chunks)} chunks from {len(docs)} file(s).")

    st.divider()
    if st.button("🗑️ Clear Chat History", use_container_width=True):
        st.session_state.messages = []
        st.rerun()

    st.markdown("### How to use")
    st.markdown(
        "1. Add PDFs to the `source/` folder\n"
        "2. Click **Ingest Documents**\n"
        "3. Ask questions below"
    )

# ── Chat history in session state ─────────────────────────────────────────────
if "messages" not in st.session_state:
    st.session_state.messages = []

# Render existing messages
for msg in st.session_state.messages:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])
        if msg.get("sources"):
            st.caption(f"📄 Sources: {', '.join(set(msg['sources']))}")

# ── Chat input ─────────────────────────────────────────────────────────────────
if prompt := st.chat_input("Ask a question about your documents…"):
    # Show user message
    st.session_state.messages.append({"role": "user", "content": prompt})
    with st.chat_message("user"):
        st.markdown(prompt)

    # Get answer
    with st.chat_message("assistant"):
        with st.spinner("Thinking…"):
            answer, sources = ask_question(prompt, st.session_state.messages)
        st.markdown(answer)
        st.caption(f"📄 Sources: {', '.join(set(sources))}")

    st.session_state.messages.append({
        "role": "assistant",
        "content": answer,
        "sources": sources,
    })
