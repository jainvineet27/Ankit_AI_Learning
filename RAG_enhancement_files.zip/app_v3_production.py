"""
RAG Q&A Chatbot - Version 3: Production-Grade Streamlit App
─────────────────────────────────────────────────────────────
Features:
  ✅ Async + streaming (non-blocking, multi-user safe)
  ✅ Per-session isolated chat history
  ✅ Feedback thumbs (👍 / 👎) per answer
  ✅ Expandable source context viewer
  ✅ Token / cost estimator in sidebar
  ✅ Retry logic on OpenAI failures
  ✅ Progress bar during ingestion
  ✅ Dark / light theme via st.set_page_config
  ✅ Graceful error handling with user-friendly messages
  ✅ Chat export (download as .txt)
"""

import asyncio
import os
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

import streamlit as st
from chromadb import PersistentClient
from dotenv import load_dotenv
from langchain_community.document_loaders import PyMuPDFLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from openai import AsyncOpenAI, APIError, RateLimitError

load_dotenv()

# ══════════════════════════════════════════════════════════════════════════════
# PAGE CONFIG  (must be first Streamlit call)
# ══════════════════════════════════════════════════════════════════════════════
st.set_page_config(
    page_title="DocuMind — RAG Assistant",
    page_icon="🧠",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items={
        "Get Help": "https://github.com/your-org/documind",
        "Report a bug": "https://github.com/your-org/documind/issues",
        "About": "**DocuMind** — Production RAG Assistant v3.0",
    },
)

# ── Custom CSS ─────────────────────────────────────────────────────────────────
st.markdown("""
<style>
/* Widen chat bubbles slightly */
.stChatMessage { max-width: 860px; margin: auto; }
/* Pill badge for sources */
.source-badge {
    display: inline-block;
    background: #1e3a5f;
    color: #e8f4f8;
    border-radius: 12px;
    padding: 2px 10px;
    font-size: 0.75rem;
    margin: 2px;
}
/* Subtle header gradient */
.main-header {
    background: linear-gradient(90deg, #1e3a5f 0%, #2d6a9f 100%);
    color: white;
    padding: 1rem 1.5rem;
    border-radius: 12px;
    margin-bottom: 1rem;
}
</style>
""", unsafe_allow_html=True)

# ══════════════════════════════════════════════════════════════════════════════
# CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════
EMBEDDING_MODEL   = "text-embedding-3-small"
CHAT_MODEL        = "gpt-4o-mini"
EMBEDDING_DIM     = 300
CHUNK_SIZE        = 500
CHUNK_OVERLAP     = 100
MAX_CONTEXT_TURNS = 6       # how many past messages to include in prompt
MAX_RETRIES       = 3       # OpenAI retry attempts

# ══════════════════════════════════════════════════════════════════════════════
# SHARED RESOURCES  (one instance across all Streamlit sessions)
# ══════════════════════════════════════════════════════════════════════════════
_EXECUTOR = ThreadPoolExecutor(max_workers=10)

@st.cache_resource(show_spinner=False)
def get_shared_resources():
    chroma = PersistentClient(path="./chromadb")
    coll   = chroma.get_or_create_collection(
        name="dump", metadata={"hnsw:space": "cosine"}
    )
    ai = AsyncOpenAI()
    return coll, ai

collection, async_client = get_shared_resources()

# ══════════════════════════════════════════════════════════════════════════════
# SESSION STATE  INIT  (isolated per browser tab)
# ══════════════════════════════════════════════════════════════════════════════
def init_session():
    defaults = {
        "session_id":   str(uuid.uuid4())[:8],
        "messages":     [],          # [{role, content, sources, feedback, ts}]
        "total_tokens": 0,
        "total_cost":   0.0,
        "ingested":     False,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_session()

# ══════════════════════════════════════════════════════════════════════════════
# ASYNC HELPERS
# ══════════════════════════════════════════════════════════════════════════════
async def run_in_executor(fn, *args):
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(_EXECUTOR, fn, *args)


def run_async(coro):
    """Bridge: call an async coroutine from Streamlit's sync context."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_closed():
            raise RuntimeError
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(coro)

# ══════════════════════════════════════════════════════════════════════════════
# CORE ASYNC RAG PIPELINE
# ══════════════════════════════════════════════════════════════════════════════
async def async_embed(texts: list[str]) -> list:
    """Async embedding with retry."""
    for attempt in range(MAX_RETRIES):
        try:
            resp = await async_client.embeddings.create(
                model=EMBEDDING_MODEL, input=texts, dimensions=EMBEDDING_DIM
            )
            return [item.embedding for item in resp.data]
        except RateLimitError:
            await asyncio.sleep(2 ** attempt)
        except APIError as e:
            if attempt == MAX_RETRIES - 1:
                raise
            await asyncio.sleep(1)
    raise RuntimeError("Embedding failed after retries.")


async def async_search(query_embedding: list) -> dict:
    def _q():
        return collection.query(query_embeddings=query_embedding, n_results=3)
    return await run_in_executor(_q)


async def async_stream_answer(
    user_query: str,
    chat_history: list,
    placeholder,
) -> tuple[str, list, int]:
    """
    Full RAG pipeline with:
    - async embedding
    - async ChromaDB retrieval
    - streaming GPT response with live typing effect
    Returns (answer, sources, tokens_used)
    """
    # 1. Embed
    user_embedding = await async_embed([user_query])

    # 2. Retrieve
    results = await async_search(user_embedding)
    retrieved_docs  = results["documents"][0]
    retrieved_metas = results["metadatas"][0]
    retrieved_context = "\n\n".join(
        f"[Chunk {i+1}] {doc}" for i, doc in enumerate(retrieved_docs)
    )
    sources = [m.get("file_name", "unknown") for m in retrieved_metas]

    # 3. Build prompt with rolling history
    history_msgs = []
    for msg in chat_history[-MAX_CONTEXT_TURNS:]:
        history_msgs.append({
            "role": msg["role"],
            "content": msg["content"],
        })

    system_prompt = f"""You are DocuMind, an expert HR document assistant.
Answer questions accurately using ONLY the retrieved context below.
Be clear, concise, and use bullet points when listing items.
If the answer is not in the context, say "I couldn't find this in the documents."

Retrieved Context:
{retrieved_context}
"""
    messages = [{"role": "system", "content": system_prompt}]
    messages += history_msgs
    messages.append({"role": "user", "content": user_query})

    # 4. Stream response
    full_answer = ""
    total_tokens = 0

    for attempt in range(MAX_RETRIES):
        try:
            async with async_client.chat.completions.stream(
                model=CHAT_MODEL,
                messages=messages,
                temperature=0.2,
                max_tokens=800,
            ) as stream:
                async for chunk in stream:
                    delta = chunk.choices[0].delta.content or ""
                    full_answer += delta
                    placeholder.markdown(full_answer + "▌")
                    await asyncio.sleep(0)      # yield control

                # Extract usage if available
                if hasattr(stream, "usage") and stream.usage:
                    total_tokens = stream.usage.total_tokens
            break

        except RateLimitError:
            await asyncio.sleep(2 ** attempt)
        except APIError:
            if attempt == MAX_RETRIES - 1:
                raise

    placeholder.markdown(full_answer)
    return full_answer, sources, total_tokens


# ══════════════════════════════════════════════════════════════════════════════
# ASYNC INGESTION
# ══════════════════════════════════════════════════════════════════════════════
async def async_ingest(progress_bar) -> tuple[int, int]:
    folder_name = "source"
    if not os.path.isdir(folder_name):
        return 0, 0

    def _load():
        docs = []
        for f in os.listdir(folder_name):
            if f.endswith(".pdf"):
                path = os.path.abspath(os.path.join(folder_name, f))
                docs.append((f, PyMuPDFLoader(path).load()))
        return docs

    raw_docs = await run_in_executor(_load)
    if not raw_docs:
        return 0, 0

    progress_bar.progress(25, text="Chunking documents…")

    def _chunk(raw):
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=CHUNK_SIZE, chunk_overlap=CHUNK_OVERLAP,
            separators=["\n\n", "\n", " ", "."],
        )
        cd, md, ids = [], [], []
        for fname, docs in raw:
            for i, chunk in enumerate(splitter.split_documents(docs)):
                cd.append(chunk.page_content)
                md.append({"file_name": fname})
                ids.append(f"chunk_{fname}_{i}")
        return cd, md, ids

    chunks, metadatas, ids = await run_in_executor(_chunk, raw_docs)
    progress_bar.progress(50, text="Creating embeddings…")

    embeddings = await async_embed(chunks)
    progress_bar.progress(75, text="Storing in ChromaDB…")

    def _store():
        collection.add(ids=ids, embeddings=embeddings,
                        documents=chunks, metadatas=metadatas)

    await run_in_executor(_store)
    progress_bar.progress(100, text="Done!")
    return len(chunks), len(raw_docs)


# ══════════════════════════════════════════════════════════════════════════════
# UTILITIES
# ══════════════════════════════════════════════════════════════════════════════
def estimate_cost(tokens: int) -> float:
    """gpt-4o-mini: $0.15 / 1M input tokens (approximate)."""
    return round(tokens * 0.00000015, 6)

def export_chat(messages: list) -> str:
    lines = [f"DocuMind Chat Export — {datetime.now().strftime('%Y-%m-%d %H:%M')}\n", "=" * 60]
    for m in messages:
        ts  = m.get("ts", "")
        role = "You" if m["role"] == "user" else "DocuMind"
        lines.append(f"\n[{ts}] {role}:\n{m['content']}")
        if m.get("sources"):
            lines.append(f"  Sources: {', '.join(set(m['sources']))}")
    return "\n".join(lines)

# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("## 🧠 DocuMind")
    st.caption("Production RAG Assistant · v3.0")
    st.divider()

    # ── Ingestion ──
    st.subheader("📥 Document Ingestion")
    if st.button("Ingest Documents", use_container_width=True, type="primary"):
        pb = st.progress(0, text="Loading PDFs…")
        try:
            n_chunks, n_files = run_async(async_ingest(pb))
            if n_files:
                st.success(f"✅ {n_chunks} chunks · {n_files} file(s)")
                st.session_state.ingested = True
            else:
                st.error("No PDFs found in `source/` folder.")
        except Exception as e:
            st.error(f"Ingestion failed: {e}")
        finally:
            time.sleep(0.5)
            pb.empty()

    st.divider()

    # ── Stats ──
    st.subheader("📊 Session Stats")
    col1, col2 = st.columns(2)
    col1.metric("Messages", len(st.session_state.messages))
    col2.metric("Tokens", st.session_state.total_tokens)
    st.caption(f"💰 Est. cost: ${st.session_state.total_cost:.5f}")

    st.divider()

    # ── Controls ──
    st.subheader("⚙️ Controls")
    if st.button("🗑️ Clear Chat", use_container_width=True):
        st.session_state.messages     = []
        st.session_state.total_tokens = 0
        st.session_state.total_cost   = 0.0
        st.rerun()

    if st.session_state.messages:
        chat_text = export_chat(st.session_state.messages)
        st.download_button(
            label="⬇️ Export Chat (.txt)",
            data=chat_text,
            file_name=f"chat_{st.session_state.session_id}.txt",
            mime="text/plain",
            use_container_width=True,
        )

    st.divider()
    st.caption(f"🔑 Session `{st.session_state.session_id}`")
    st.caption("Each tab = isolated session")

# ══════════════════════════════════════════════════════════════════════════════
# MAIN AREA
# ══════════════════════════════════════════════════════════════════════════════
st.markdown("""
<div class="main-header">
  <h2 style="margin:0">🧠 DocuMind — RAG Document Assistant</h2>
  <p style="margin:0;opacity:0.85">Ask questions about your HR documents · Powered by ChromaDB + OpenAI</p>
</div>
""", unsafe_allow_html=True)

# Warn if not ingested
if not st.session_state.ingested:
    st.info("💡 Ingest documents first using the sidebar to start asking questions.", icon="ℹ️")

st.divider()

# ── Render chat history ────────────────────────────────────────────────────────
for idx, msg in enumerate(st.session_state.messages):
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])

        if msg["role"] == "assistant":
            # Sources as pills
            if msg.get("sources"):
                src_html = " ".join(
                    f'<span class="source-badge">📄 {s}</span>'
                    for s in set(msg["sources"])
                )
                st.markdown(src_html, unsafe_allow_html=True)

            # Expandable retrieved context (stored per message)
            if msg.get("context"):
                with st.expander("🔍 View retrieved context"):
                    st.text(msg["context"])

            # Feedback
            fb_key = f"fb_{idx}"
            if msg.get("feedback") is None:
                c1, c2, _ = st.columns([1, 1, 8])
                if c1.button("👍", key=f"up_{idx}"):
                    st.session_state.messages[idx]["feedback"] = "positive"
                    st.rerun()
                if c2.button("👎", key=f"dn_{idx}"):
                    st.session_state.messages[idx]["feedback"] = "negative"
                    st.rerun()
            else:
                emoji = "👍" if msg["feedback"] == "positive" else "👎"
                st.caption(f"Feedback: {emoji}")

# ── Chat input ─────────────────────────────────────────────────────────────────
if user_input := st.chat_input("Ask a question about your documents…"):
    ts = datetime.now().strftime("%H:%M:%S")

    # Append + render user message
    st.session_state.messages.append({
        "role": "user", "content": user_input, "ts": ts
    })
    with st.chat_message("user"):
        st.markdown(user_input)

    # Generate assistant response
    with st.chat_message("assistant"):
        stream_placeholder = st.empty()
        try:
            answer, sources, tokens = run_async(
                async_stream_answer(
                    user_input,
                    st.session_state.messages,
                    stream_placeholder,
                )
            )

            # Source pills
            if sources:
                src_html = " ".join(
                    f'<span class="source-badge">📄 {s}</span>'
                    for s in set(sources)
                )
                st.markdown(src_html, unsafe_allow_html=True)

            # Update session stats
            st.session_state.total_tokens += tokens
            st.session_state.total_cost   += estimate_cost(tokens)

            st.session_state.messages.append({
                "role":     "assistant",
                "content":  answer,
                "sources":  sources,
                "feedback": None,
                "ts":       datetime.now().strftime("%H:%M:%S"),
            })

        except RateLimitError:
            stream_placeholder.error(
                "⚠️ Rate limit reached. Please wait a moment and try again."
            )
        except Exception as e:
            stream_placeholder.error(f"❌ Something went wrong: {e}")
