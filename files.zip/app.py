"""
app.py
──────
Streamlit UI for DataGPT.
All agent logic lives in agent_core.py — this file only handles the UI.
"""

import pandas as pd
import streamlit as st
from dotenv import load_dotenv

from agent_core import run_agent_sync
from connect_to_db_2 import execute_query

load_dotenv()

st.set_page_config(page_title="DataGPT - Agentic SQL", page_icon="📊", layout="wide")


# ── Session state ─────────────────────────────────────────────────────────────

if "messages" not in st.session_state:
    st.session_state["messages"] = []       # chat history: list of {role, content}

if "agent_logs" not in st.session_state:
    st.session_state["agent_logs"] = []     # tool-call trace lines

if "last_sql" not in st.session_state:
    st.session_state["last_sql"] = ""       # most recent generated SQL

if "last_result" not in st.session_state:
    st.session_state["last_result"] = None  # most recent query result (DataFrame)


# ── Helpers ───────────────────────────────────────────────────────────────────

def to_dataframe(raw) -> pd.DataFrame | None:
    """Convert whatever execute_query returns into a DataFrame, or None if empty."""
    if isinstance(raw, pd.DataFrame):
        return raw if not raw.empty else None
    if isinstance(raw, list) and raw:
        return pd.DataFrame(raw)
    if isinstance(raw, dict) and raw:
        return pd.DataFrame([raw])
    return None


# ── Page header ───────────────────────────────────────────────────────────────

st.title("📊 DataGPT — Agentic SQL")
st.caption("Ask a question in plain English. The agent inspects your schema and writes the SQL.")


# ── Chat history ──────────────────────────────────────────────────────────────

for msg in st.session_state["messages"]:
    with st.chat_message(msg["role"]):
        st.markdown(msg["content"])


# ── Results panel (persists across reruns) ────────────────────────────────────

if st.session_state["last_sql"]:

    with st.expander("🔍 Agent Tool-Calling Trace", expanded=False):
        for line in st.session_state["agent_logs"]:
            st.write(line)

    with st.container(border=True):
        st.subheader("📝 Generated SQL")
        st.code(st.session_state["last_sql"], language="sql")

    with st.container(border=True):
        st.subheader("📋 Query Output")
        df = st.session_state["last_result"]
        if df is not None:
            st.dataframe(df, use_container_width=True, hide_index=True)
            st.caption(f"{len(df):,} row(s) returned")
        else:
            st.info("Query ran successfully but returned no records.")


# ── Chat input ────────────────────────────────────────────────────────────────

if user_question := st.chat_input("e.g. How many courses are offered per department?"):

    # Save and show user message
    st.session_state["messages"].append({"role": "user", "content": user_question})
    with st.chat_message("user"):
        st.markdown(user_question)

    # Clear logs for this new run
    st.session_state["agent_logs"] = []

    with st.chat_message("assistant"):
        with st.spinner("Agent is working…"):
            try:
                # Step 1 — run agent (logs written inside agent_core directly to session state)
                generated_sql = run_agent_sync(user_question)
                st.session_state["last_sql"] = generated_sql

                # Step 2 — execute the SQL
                raw_result = execute_query(generated_sql)
                df = to_dataframe(raw_result)
                st.session_state["last_result"] = df

                row_count = len(df) if df is not None else 0
                reply = (
                    f"Done! Query returned **{row_count:,} row(s)**."
                    if row_count
                    else "Query ran successfully but returned no records."
                )

            except Exception as err:
                reply = f"❌ Error: {err}"
                st.session_state["last_sql"] = ""
                st.session_state["last_result"] = None

            st.markdown(reply)
            st.session_state["messages"].append({"role": "assistant", "content": reply})

    st.rerun()
