"""
agent_core.py
─────────────
Business logic for the DataGPT agentic SQL pipeline.
No Streamlit imports here — purely the agent loop and tool definitions.
"""

import asyncio
from openai import AsyncOpenAI
import streamlit as st

from orchestrator import concurrent_runs
from my_system_prompt import system_prompt

MODEL = "gpt-5.6-luna"
MAX_TURNS = 5

TOOLS = [
    {
        "type": "function",
        "name": "get_stock_details",
        "description": "Provide information on the latest stock details based on user-provided stock code",
        "parameters": {
            "type": "object",
            "properties": {
                "stock_code": {
                    "type": "string",
                    "description": "An NSE stock code provided by user input",
                }
            },
            "required": ["stock_code"],
        },
    },
    {
        "type": "function",
        "name": "get_schema",
        "description": "Provide schema and column details for a given table, required before writing SQL",
        "parameters": {
            "type": "object",
            "properties": {
                "schema_name": {
                    "type": "string",
                    "description": "Schema name (logical container of tables)",
                },
                "table_name": {
                    "type": "string",
                    "description": "Table name which stores the actual data",
                },
            },
            "required": ["schema_name", "table_name"],
        },
    },
    {
        "type": "function",
        "name": "get_table",
        "description": "Provide table details matching the user's question",
        "parameters": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Schema name"},
                "table_name":  {"type": "string", "description": "Table name"},
            },
            "required": ["schema_name", "table_name"],
        },
    },
]


async def run_agent(user_input: str) -> str:
    """
    Runs the tool-calling loop and returns the final SQL string.
    Logs are written directly to st.session_state["agent_logs"] as they happen.
    Raises an exception on failure so the caller can handle it.
    """
    client = AsyncOpenAI()
    full_prompt = f"{system_prompt}\nUser question: {user_input}"

    response = await client.responses.create(
        model=MODEL,
        input=full_prompt,
        tools=TOOLS,
    )
    response_id = response.id

    for turn in range(1, MAX_TURNS + 1):
        tool_calls = [item for item in response.output if item.type == "function_call"]

        if not tool_calls:
            st.session_state["agent_logs"].append(
                f"Turn {turn}: No further tools needed — generating SQL."
            )
            break

        st.session_state["agent_logs"].append(
            f"Turn {turn}: Model requested {len(tool_calls)} tool call(s)."
        )
        for call in tool_calls:
            st.session_state["agent_logs"].append(
                f"  → `{call.name}` args: {call.arguments}"
            )

        tools_output = await concurrent_runs(tool_calls)

        st.session_state["agent_logs"].append(f"Turn {turn}: Tools executed successfully.")

        response = await client.responses.create(
            model=MODEL,
            input=tools_output,
            previous_response_id=response_id,
        )
        response_id = response.id
    else:
        st.session_state["agent_logs"].append(
            f"Reached max turns ({MAX_TURNS}). Using last model response."
        )

    raw_sql = response.output_text.strip()
    clean_sql = (
        raw_sql
        .removeprefix("```sql")
        .removeprefix("```")
        .removesuffix("```")
        .strip()
    )
    return clean_sql


def run_agent_sync(user_input: str) -> str:
    """Blocking wrapper — call this from Streamlit."""
    return asyncio.run(run_agent(user_input))
